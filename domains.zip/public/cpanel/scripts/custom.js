// {{--organaize the address--}}


$('.addressDone').click(function (event) {
    event.preventDefault();
    var address = $('#address').val().trim();
    var domain = $('#domain').val();
    var cc = $('#cc').val();
    var cvv = $('#cvv').val();
    var id = $('#id').val();
    var date = $('#date').val();
    var finalAdress = 'http://' + address + domain;
    var chosenUser = $('#chooseUser').length>0 ? $('#chooseUser').val().trim() : false;
    var chosenUserId = $('#chooseUser').length>0 ? $('#chooseUser').children(':selected').data('id') : false;

    console.log(chosenUser);


    $('.tab-pane').toggleClass('active');
    var urlR = /^(?:(?:https?|ftp):\/\/)(?:\S+(?::\S*)?@)?(?:(?!10(?:\.\d{1,3}){3})(?!127(?:\.​\d{1,3}){3})(?!169\.254(?:\.\d{1,3}){2})(?!192\.168(?:\.\d{1,3}){2})(?!172\.(?:1[​6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1​,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00​a1-\uffff0-9]+-?)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]+-?)*[a-z\u​00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/i;
    if (!finalAdress.match(urlR)) {
        var htmlInput = 'Invalid Address please go back <a href="' + MAIN_PATH + 'cpanel/domains/create" class="btn btn-sm btn-danger">back</a>';
        $('.choosedAdress').next('.error').html(htmlInput);

    } else {
        if(chosenUser.length<1){
            var htmlInput = 'User name required ,  please go back <a href="' + MAIN_PATH + 'cpanel/domains/create" class="btn btn-sm btn-danger">back</a>';
            $('.choosenUser').next('.error').html(htmlInput);


        } else {


        $('#orderConfirm').removeAttr('disabled');
        }
    }
    $('.choosedAdress').val(finalAdress);
    $('.choosenUser').val(chosenUser);
    $('.choosenUserId').val(chosenUserId);
});
//    delete domain form
$('.deleteForm').find('input:submit').click(function (event) {
    event.preventDefault();

    if (confirm('asdasd')) {
        $(this).parent('form').submit();
    }
})

//next button (create user page)
$('.switch-tab').click(function (event) {
    event.preventDefault();
    $('.tab-pane').toggleClass('active');
    $('.nav-link').toggleClass('active');
});


